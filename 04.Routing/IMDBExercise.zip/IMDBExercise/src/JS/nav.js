import history from "./history";

export default function nav(loc) {
  history.push(loc);
}