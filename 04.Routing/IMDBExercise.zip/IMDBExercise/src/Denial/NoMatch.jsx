import React from 'react';

const NoMatch = () => (
	<h1>404 Page not found</h1>
);

export default NoMatch;